package fhkufstein.at.ac;


public class seuebung {

    public static void main(String[] args) {

        String schule = "FH Kufstein Tirol";
        System.out.println(schule);

    }

}
