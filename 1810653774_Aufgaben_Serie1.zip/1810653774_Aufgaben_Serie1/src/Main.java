
public class Main {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        String name = "Benedikt Oltersdorf";
        System.out.println(name);
        System.out.println();;
    }





}